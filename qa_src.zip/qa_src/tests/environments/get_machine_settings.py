machine = {
        'xp': {'image': '/home/tester/vmware/Windows XP Professional/Windows XP Professional.vmx',
            'guest_ip':'10.0.0.166',
            'remote_library_address':'10.0.1.15:7777'},
        }
def get_variables(os):
    return machine[os]
