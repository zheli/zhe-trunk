__version__ = '1.0'
import sys, os, platform

class VerificationLibrary:
    """
    VerificationLibrary is a helper library for robot framework that enhances the built-in verfication modules.
    """
    ROBOT_LIBRARY_SCOPE = 'TEST CASE'
    ROBOT_LIBRARY_VERSION = __version__

    def __init__(self):
        self._default_log_level = 'INFO'

    def get_public_desktop_path(self):
        """
        Get the path to public desktop folder
        """
        from win32com.shell import shell, shellcon
        return shell.SHGetFolderPath(0, shellcon.CSIDL_COMMON_DESKTOPDIRECTORY, None, 0) + '\\'

    def get_aaw_path(self):
        """
        Get the default install path of Ad-Aware
        """
        return os.path.expandvars('%PROGRAMFILES%\\Lavasoft\\Ad-Aware')
    
    def check_language_settings_in_registry(self, language):
        """
        Get the language setting in registry
        """
        from AutoItLibrary import AutoItLibrary
        autoit = AutoItLibrary()
        reg_data = autoit.RegRead('HKEY_LOCAL_MACHINE\\SOFTWARE\\Lavasoft\\Ad-Aware', 'Language')
        assert reg_data == language, 'Language setting is incorrect!'

    def check_screenshots(self, language, filename):
        """
        Compare screenshots to the reference files in a specified language
        """
        current_screenshots_folder = 'current_screens\\' + language + '\\'

        if not(self.isWin7_32()): #Only compares screen shot on Windows 7 32bit
            maxThreshold = 100
            #Set the minimum similarity here
            #threshold = 99.959745545
            threshold = maxThreshold
            ref = 'screenshots\\' + language + '\\' + filename
            filename = current_screenshots_folder + filename
            self._debug('comparing %s to %s' % (filename, ref))
            if not (self._pic_similarity(filename, ref) == threshold):
                diff_image = self._diff_images(filename, ref)
                self._html('<td></td></tr><tr><td colspan="3"><a href="%s">'
                        '<img src="%s" width="700px"></a></td></tr>' % (diff_image, diff_image))
                raise Exception('There is something different in [%s]!' % filename)

    def _diff_images(self, filename, ref):
        import ImageChops, Image
        i1 = Image.open(filename)
        i2 = Image.open(ref)

        result_image = ImageChops.difference(i1, i2)
        result_filename = filename[:-4] + '_diff.png'
        result_image.save(result_filename)

        return result_filename

    def _pic_similarity(self, filename, ref):
        #reference: http://rosettacode.org/wiki/Percentage_difference_between_images#Python
        from itertools import izip
        import Image
        
        try:
            i1 = Image.open(filename)
        except:
            #If the current screen shot does not exist, it means AutoIt did not take it. Pass
            raise Exception('Failed to find screenshot [%s]' % filename)
        i2 = Image.open(ref)
        assert i1.mode == i2.mode, "Different kinds of images."
        assert i1.size == i2.size, "Different sizes."
         
        pairs = izip(i1.getdata(), i2.getdata())
        if len(i1.getbands()) == 1:
            # for gray-scale jpegs
            dif = sum(abs(p1-p2) for p1,p2 in pairs)
        else:
            dif = sum(abs(c1-c2) for p1,p2 in pairs for c1,c2 in zip(p1,p2))
         
        ncomponents = i1.size[0] * i1.size[1] * 3
        similarity = 100-(dif / 255.0 * 100) / ncomponents
        
        return similarity    

    def get_file_md5(self, filename):
        """
        Get MD5 value for the file
        """
        from hashlib import md5
        file_md5 = md5()
        block_size = 2**20
        with open(filename, 'rb') as f:
            while True:
                chunk = f.read(block_size)
                if not chunk:
                    break
                file_md5.update(chunk)
        return file_md5.hexdigest()

    def is_x64(self):
        """
        Check if the testing platform is 64bit, returns {True|False}
        """
        try:
            if platform.machine() != 'x86':
                return True
        except:
            return False
        
    def isWin7_32(self):
        """
        Check if the testing platform is Windows 7 32bit, returns {True|False}
        """
        if platform.release() == '7' and (not self.is_x64()):
            return True 

        return False

    def get_process_pid(self, process):
        """
        Get the PID of the process
        """
        from win32com.client import GetObject
        WMI = GetObject('winmgmts:')
        processes = WMI.InstancesOf('Win32_Process')
        process_list = [(p.Properties_('ProcessID').Value, p.Properties_('Name').Value) for p in processes]
        for p in process_list:
            if p[1] == process:
                pid = p[0]
        if pid:
            return pid
        else:
            raise Exception('Process not found!!')

    def get_server_filelist(self, server_url):
        import urllib

        urllib.urlretrieve(server_url, 'meta_tmp.xml')
        return self._get_update_filelist('meta_tmp.xml')

    def get_checksum_from_server(self, filename):
        checksums = self._get_update_checksums('meta_tmp.xml')
        if self.is_x64():
            return checksums[filename].get('64', checksums[filename].get('32'))
        else:
            return checksums[filename].get('32')

    def _get_update_checksums(self, filename):
        """
        Parse metafile.dat and return the file MD5s dictionary
        """
        import xml.etree.ElementTree as ET

        tree = ET.parse(filename)
        elem = tree.getroot()
        filelist = elem.find('filelist')
        checksums = elem.find('checksums')
        files = {}
        for file in filelist:
            files[file.text] = {}
            for checksum in checksums:
                if file.tag == checksum.tag:
                    files[file.text][checksum.get('platform')] = checksum.get('md5')

        return files

    def _get_update_filelist(self, filename):
        """
        Parse metafile.dat and return the updated file list
        """
        import xml.etree.ElementTree as ET

        tree = ET.parse(filename)
        elem = tree.getroot()
        filelist = elem.find('filelist')
        files = []
        for file in filelist:
            files.append(file.text)

        return files

    def _debug(self, msg):
        self._log(msg, 'DEBUG')

    def _warn(self, msg):
        self._log(msg, 'WARN')

    def _info(self, msg):
        self._log(msg, 'INFO')
    
    def _html(self, msg):
        self._log(msg, 'HTML')

    def _log(self, msg, level = None):
        msg = msg.strip()
        if not level:
            level = self._default_log_level
        if msg:
            print('*%s* %s' % (level.upper(), msg))

if __name__== '__main__':
    from robotremoteserver import RobotRemoteServer
    RobotRemoteServer(VerificationLibrary(), *sys.argv[1:])
