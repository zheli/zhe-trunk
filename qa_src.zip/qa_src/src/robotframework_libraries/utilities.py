import os, sys
from subprocess import Popen, PIPE

def run( command, verbose = False, output = False ):
    if verbose:
        sys.stdout.write( " ".join( command ) + "\n" )
        sys.stdout.flush()

    data = []
    try:
        p = Popen(command, bufsize=0, stderr=PIPE, stdout=PIPE)
        out_output = p.stdout
        err_output = p.stderr
        pid = p.pid

        if verbose or output:
            for line in iter(out_output.readline, ''):
                if output:
                    data.append( line.rstrip() )
                if verbose:
                    sys.stdout.write( line.rstrip() + "\n" )
                    sys.stdout.flush() 

            for line in iter(err_output.readline, ''):
                if verbose:
                    sys.stderr.write( line.rstrip() + "\n" )
                    sys.stderr.flush() 
        
        exitcode = p.wait()

        if output:
            return ( exitcode, data, pid )

        return exitcode

    except Exception, inst:
        print inst.args
        sys.stdout.flush() 
        sys.stderr.flush() 

    if output:
	    return ( 1, [] )
    return 1


