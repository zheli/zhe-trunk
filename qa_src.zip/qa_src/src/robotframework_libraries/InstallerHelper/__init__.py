__version__ = '1.0'
from AutoItLibrary import *

class InstallerHelper:
    """Wix Installer Library is a test library for robot framework. It helps you testing WIX-based installer.
    """
    ROBOT_LIBRARY_SCOPE = 'TEST SUITE'
    ROBOT_LIBRARY_VERSION = __version__
    def __init__(self):
        self._default_log_level = 'INFO'
        self._AutoIt = AutoItLibrary(OutputDir = 'C:\\')
        self._AutoItCom = self._AutoIt._AutoIt
        
    def choose_language(self, language):
        if language.lower() == 'french':
            self._AutoIt.Send('{DOWN}')
            return
        return
    
    def _debug(self, msg):
        self._log(msg, 'DEBUG')
        
    def _info(self, msg):
        self._log(msg, 'INFO')

    def _log(self, msg, level = None):
        msg = msg.strip()
        if not level:
            level = self._default_log_level
        if msg:
            print('*%s* %s' % (level.upper(), msg))

if __name__== '__main__':
    from robotremoteserver import RobotRemoteServer
    RobotRemoteServer(InstallerHelper(), *sys.argv[1:])
