__version__ = '1.0'
import sys, os
sys.path.append('C:\\Test\libs')
import _winreg
from AutoItLibrary import *
from utilities import run
import json

class aaw_library:
    """
    """
    ROBOT_LIBRARY_SCOPE = 'TEST SUITE'
    ROBOT_LIBRARY_VERSION = __version__
    def __init__(self):
        self._default_log_level = 'INFO'
        self._AutoIt = AutoItLibrary(OutputDir = 'C:\\')
        self._AutoItCom = self._AutoIt._AutoIt
        self.program_files = _winreg.ExpandEnvironmentStrings(u"%ProgramFiles(x86)%")
        if self.program_files == u"%ProgramFiles(x86)%":
           self.program_files = _winreg.ExpandEnvironmentStrings(u"%ProgramFiles%")

    def start_update(self):
        (exitcode, output, pid) = run('C:\\test\\service.bat', verbose=True, output=True)
        self.update_result = json.loads(output[0])
        return exitcode, pid, self.update_result

    def get_update_manager_version(self):
        return 5

    def check_if_update_restarted(self):
        return True        
        
    def get_updated_filelist(self):
        filelist = []
        for file in self.update_result['updated_files']:
            filelist.append(file['filename'])

        return filelist

    def _debug(self, msg):
        self._log(msg, 'DEBUG')
        
    def _info(self, msg):
        self._log(msg, 'INFO')

    def _log(self, msg, level = None):
        msg = msg.strip()
        if not level:
            level = self._default_log_level
        if msg:
            print('*%s* %s' % (level.upper(), msg))

if __name__== '__main__':
    from robotremoteserver import RobotRemoteServer
    RobotRemoteServer(aaw_library(), *sys.argv[1:])
